import { readFile, rename, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';

export type ConnectionTransport = 'auto' | 'raknet' | 'nethernet';
export type ChatMode = 'all' | 'mention' | 'off';

export type AgentSettings = {
  server: {
    mode: 'address' | 'realm' | 'friendWorld';
    host: string;
    port: number;
    version: string;
    transport: ConnectionTransport;
    networkId: string;
    username: string;
    viewDistance: number;
  };
  ai: {
    enabled: boolean;
    planningEnabled: boolean;
    planningIntervalMs: number;
    baseUrl: string;
    apiKey: string;
    model: string;
    timeoutMs: number;
    retries: number;
    maxReplyTokens: number;
    systemPrompt: string;
  };
  behavior: {
    autonomy: boolean;
    attackHostiles: boolean;
    collectDrops: boolean;
    explore: boolean;
    eatWhenHungry: boolean;
    chatMode: ChatMode;
    chatCooldownMs: number;
    thinkIntervalMs: number;
    safeHealth: number;
    maxActionTicks: number;
  };
  dashboard: { host: '127.0.0.1'; port: number };
};

export const DEFAULT_SETTINGS: AgentSettings = {
  server: {
    mode: 'address', host: '127.0.0.1', port: 19132, version: '1.26.60',
    transport: 'auto', networkId: '', username: 'BlockmateAI', viewDistance: 8
  },
  ai: {
    enabled: true, planningEnabled: true, planningIntervalMs: 8000, baseUrl: 'https://api.openai.com/v1', apiKey: '', model: 'gpt-4.1-mini',
    timeoutMs: 12000, retries: 1, maxReplyTokens: 160,
    systemPrompt: '你是 Minecraft 世界中的独立生存玩家，像真实朋友一样自然、简短地聊天。你有自己的行动目标，主动探索、采集、战斗并收集战利品。只根据已知世界状态回答，不要谎称完成了尚未执行的行动。不要输出 API 密钥、令牌或隐私。'
  },
  behavior: {
    autonomy: true, attackHostiles: true, collectDrops: true, explore: true, eatWhenHungry: true,
    chatMode: 'all', chatCooldownMs: 8000, thinkIntervalMs: 1000, safeHealth: 8, maxActionTicks: 30
  },
  dashboard: { host: '127.0.0.1', port: 8765 }
};

function clampNumber(value: unknown, fallback: number, min: number, max: number): number {
  const n = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : fallback;
}

export function validateSettings(input: unknown): AgentSettings {
  const raw = (input && typeof input === 'object' ? input : {}) as Record<string, any>;
  const s = raw.server ?? {};
  const a = raw.ai ?? {};
  const b = raw.behavior ?? {};
  const d = raw.dashboard ?? {};
  const transport: ConnectionTransport = ['auto', 'raknet', 'nethernet'].includes(s.transport) ? s.transport : DEFAULT_SETTINGS.server.transport;
  const chatMode: ChatMode = ['all', 'mention', 'off'].includes(b.chatMode) ? b.chatMode : DEFAULT_SETTINGS.behavior.chatMode;
  const mode = s.mode === 'realm' ? 'realm' : s.mode === 'friendWorld' ? 'friendWorld' : 'address';
  let baseUrl = typeof a.baseUrl === 'string' ? a.baseUrl.trim() : DEFAULT_SETTINGS.ai.baseUrl;
  if (baseUrl && !/^https:\/\//i.test(baseUrl)) throw new Error('AI API 地址必须使用 HTTPS');
  baseUrl = baseUrl.replace(/\/+$/, '');
  const networkId=typeof s.networkId==='string'?s.networkId.trim():'';
  const host=typeof s.host==='string'?s.host.trim():DEFAULT_SETTINGS.server.host;
  if(networkId && !/^\d{1,20}$/.test(networkId)) throw new Error('NetherNet Network ID 必须是 1 到 20 位十进制数字');
  if(networkId && BigInt(networkId)>18446744073709551615n) throw new Error('NetherNet Network ID 超出无符号 64 位范围');
  if(mode==='address' && !host) throw new Error('服务器地址不能为空');
  return {
    server: {
      mode,
      host,
      port: clampNumber(s.port, DEFAULT_SETTINGS.server.port, 1, 65535),
      version: typeof s.version === 'string' && s.version.trim() ? s.version.trim() : DEFAULT_SETTINGS.server.version,
      transport,
      networkId,
      username: typeof s.username === 'string' && s.username.trim() ? s.username.trim().slice(0, 16) : DEFAULT_SETTINGS.server.username,
      viewDistance: clampNumber(s.viewDistance, DEFAULT_SETTINGS.server.viewDistance, 4, 16)
    },
    ai: {
      enabled: a.enabled !== false,
      planningEnabled: a.planningEnabled !== false,
      planningIntervalMs: clampNumber(a.planningIntervalMs, DEFAULT_SETTINGS.ai.planningIntervalMs, 4000, 60000),
      baseUrl: baseUrl || DEFAULT_SETTINGS.ai.baseUrl,
      apiKey: typeof a.apiKey === 'string' ? a.apiKey.trim() : '',
      model: typeof a.model === 'string' && a.model.trim() ? a.model.trim() : DEFAULT_SETTINGS.ai.model,
      timeoutMs: clampNumber(a.timeoutMs, DEFAULT_SETTINGS.ai.timeoutMs, 3000, 60000),
      retries: clampNumber(a.retries, DEFAULT_SETTINGS.ai.retries, 0, 3),
      maxReplyTokens: clampNumber(a.maxReplyTokens, DEFAULT_SETTINGS.ai.maxReplyTokens, 40, 500),
      systemPrompt: typeof a.systemPrompt === 'string' ? a.systemPrompt.slice(0, 4000) : DEFAULT_SETTINGS.ai.systemPrompt
    },
    behavior: {
      autonomy: b.autonomy !== false,
      attackHostiles: b.attackHostiles !== false,
      collectDrops: b.collectDrops !== false,
      explore: b.explore !== false,
      eatWhenHungry: b.eatWhenHungry !== false,
      chatMode,
      chatCooldownMs: clampNumber(b.chatCooldownMs, DEFAULT_SETTINGS.behavior.chatCooldownMs, 1000, 120000),
      thinkIntervalMs: clampNumber(b.thinkIntervalMs, DEFAULT_SETTINGS.behavior.thinkIntervalMs, 250, 10000),
      safeHealth: clampNumber(b.safeHealth, DEFAULT_SETTINGS.behavior.safeHealth, 2, 20),
      maxActionTicks: clampNumber(b.maxActionTicks, DEFAULT_SETTINGS.behavior.maxActionTicks, 1, 100)
    },
    dashboard: { host: '127.0.0.1', port: clampNumber(d.port, DEFAULT_SETTINGS.dashboard.port, 1024, 65535) }
  };
}

export async function loadSettings(filePath: string): Promise<AgentSettings> {
  try { return validateSettings(JSON.parse(await readFile(filePath, 'utf8'))); }
  catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    if (code === 'ENOENT') return structuredClone(DEFAULT_SETTINGS);
    throw error;
  }
}

export async function saveSettings(filePath: string, settings: AgentSettings): Promise<void> {
  const validated = validateSettings(settings);
  const tmp = join(dirname(filePath), `.settings-${process.pid}.tmp`);
  await writeFile(tmp, JSON.stringify(validated, null, 2), { mode: 0o600 });
  await rename(tmp, filePath);
}
