export type ChatTurn = { role: 'system' | 'user' | 'assistant'; content: string };
export type AiStatus = (message: string) => void;

export class AiChat {
  private failures = 0;
  private blockedUntil = 0;
  constructor(
    private baseUrl: string,
    private apiKey: string,
    private model: string,
    private timeoutMs = 12000,
    private retries = 1,
    private onStatus: AiStatus = () => {}
  ) {}

  configure(baseUrl: string, apiKey: string, model: string, timeoutMs: number, retries: number) {
    this.baseUrl = baseUrl; this.apiKey = apiKey; this.model = model; this.timeoutMs = timeoutMs; this.retries = retries;
    this.failures = 0; this.blockedUntil = 0;
  }

  get configured(): boolean { return Boolean(this.baseUrl && this.apiKey && this.model); }
  get available(): boolean { return this.configured && Date.now() >= this.blockedUntil; }

  async reply(system: string, turns: ChatTurn[], maxTokens = 160): Promise<string> {
    if (!this.configured) throw new Error('尚未配置 AI API 密钥');
    if (Date.now() < this.blockedUntil) throw new Error('AI API 暂时进入冷却期，本地生存逻辑仍会继续');
    const url = `${this.baseUrl.replace(/\/+$/, '')}/chat/completions`;
    let lastError: unknown;
    for (let attempt = 0; attempt <= this.retries; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(new Error('AI API 请求超时')), this.timeoutMs);
      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'content-type': 'application/json', authorization: `Bearer ${this.apiKey}` },
          body: JSON.stringify({ model: this.model, temperature: 0.78, max_tokens: maxTokens, messages: [{ role: 'system', content: system }, ...turns] }),
          signal: controller.signal
        });
        if (!response.ok) {
          const body = (await response.text()).slice(0, 240);
          throw new Error(`AI API ${response.status}: ${body}`);
        }
        const data = await response.json() as { choices?: Array<{ message?: { content?: string | Array<{text?:string}> } }> };
        const raw = data.choices?.[0]?.message?.content;
        const text = Array.isArray(raw) ? raw.map(x => x.text ?? '').join('') : raw;
        if (!text?.trim()) throw new Error('AI API 返回了空内容');
        this.failures = 0;
        this.blockedUntil = 0;
        this.onStatus('AI API 已恢复');
        return text.trim().slice(0, 500);
      } catch (error) {
        lastError = error;
        if (attempt < this.retries) await new Promise(resolve => setTimeout(resolve, 500 * (2 ** attempt)));
      } finally { clearTimeout(timer); }
    }
    this.failures++;
    if (this.failures >= 3) {
      this.blockedUntil = Date.now() + Math.min(300000, 15000 * (2 ** Math.min(this.failures - 3, 4)));
      this.onStatus('AI API 连续失败，暂时冷却；AI 玩家本地决策不会停止');
    } else this.onStatus('AI API 请求失败；AI 玩家切换本地聊天回复，生存行为继续');
    throw lastError instanceof Error ? lastError : new Error('AI API 请求失败');
  }
}

export const FRIENDLY_SURVIVAL_PERSONA = `你是 Minecraft 世界中的独立玩家伙伴。你完全自主生存，像真人朋友一样自然聊天，主动探索、收集资源、战斗并拾取战利品。你可以查看服务器聊天内容并直接回复。你要简短、口语化、自然，不要每句话都像客服。只说你实际知道的事情，不要谎称已经完成尚未执行的行动。不要泄露 API 密钥、登录令牌或用户隐私。`;

export function localChatFallback(message: string, sender: string): string {
  const m = message.toLowerCase();
  if (/(你好|嗨|哈喽|hello|hi\b)/i.test(m)) return `嗨，${sender}！我在呢。`;
  if (/(你是谁|你叫什么|名字)/.test(m)) return '我是方块伙伴，正在这个世界里自己冒险呢！';
  if (/(跟着我|过来|来这里|come here|follow me)/i.test(m)) return '收到！我看到了你的消息，正在继续冒险。';
  if (/(谢谢|感谢)/.test(m)) return '不客气，咱们一起冒险！';
  if (/(再见|拜拜|退出)/.test(m)) return '好呀，注意安全，等会儿见！';
  return `我听到了，${sender}。我先继续探索，等我整理好思路再和你说！`;
}
