import { decide } from './brain.js';
import type { GameTransport } from './types.js';
import type { AgentSettings } from './config.js';
import type { AiPlanner, PlannedDecision } from './planner.js';

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export class AgentRuntime {
  private running = false;
  private loopPromise?: Promise<void>;
  private statusText = '未启动';
  private activeGoal = '待机';
  private tickErrors = 0;
  private cachedPlan: { decision:PlannedDecision; expiresAt:number } | null = null;
  private plannerBusy = false;
  private nextPlanAt = 0;

  constructor(
    private transport: GameTransport,
    private getSettings: () => AgentSettings,
    private onStatus: (s: string) => void = () => {},
    private planner?: AiPlanner
  ) {}

  get status() { return { running: this.running, status: this.statusText, goal: this.activeGoal, errors: this.tickErrors }; }

  async start() {
    if (this.running) return;
    this.running = true;
    this.setStatus('正在连接 Minecraft…');
    this.loopPromise = this.runLoop();
    // Do not await the permanent loop here: callers (dashboard HTTP handlers) must return immediately.
    void this.loopPromise.catch(error => this.setStatus(`运行循环异常：${(error as Error).message}`));
    return;
  }

  private setStatus(s: string) { this.statusText = s; this.onStatus(s); }

  private async runLoop() {
    let reconnectDelay = 1500;
    try {
      while (this.running) {
        try {
          if (!this.transport.isConnected?.()) {
            this.setStatus('正在连接游戏服务器…');
            await this.transport.connect();
            reconnectDelay = 1500;
            this.setStatus('AI 玩家已加入，正在自主生存');
          }
          const settings = this.getSettings();
          if (!settings.behavior.autonomy) {
            this.activeGoal = '自主行为已暂停';
            await sleep(500);
            continue;
          }
          const world = await this.transport.readWorldSnapshot();
          const localDecision = decide(world, settings.behavior);
          this.scheduleAiPlan(world, settings);
          const emergencyGoal = ['survive', 'fight', 'collect_loot', 'gather_food'].includes(localDecision.goal);
          let decision: { goal:string; actions: typeof localDecision.actions; reason:string } = localDecision;
          if (!emergencyGoal && this.cachedPlan) {
            if (this.cachedPlan.expiresAt > Date.now()) {
              const planned=this.cachedPlan.decision;
              const hasProgressAction=planned.actions.some(action=>['move','jump','attack','collect','break','place','useItem'].includes(action.type));
              // The API may choose to look, sneak, or wait. Never let a passive plan
              // replace the local exploration driver indefinitely: append one safe local
              // movement cycle so a configured API can never make the bot stand still.
              const fallbackMove=localDecision.actions.filter(action=>action.type==='move'||action.type==='jump');
              decision={...planned,actions:hasProgressAction?planned.actions:[...planned.actions,...fallbackMove].slice(0,3)};
            }
            this.cachedPlan = null; // one-shot plan: never repeat stale API actions indefinitely
          } else if (this.cachedPlan && this.cachedPlan.expiresAt <= Date.now()) {
            this.cachedPlan = null;
          }
          this.activeGoal = decision.goal;
          this.setStatus(`目标：${decision.goal}；${decision.reason}`);
          for (const action of decision.actions.slice(0, 3)) {
            if (!this.running) break;
            try { await this.transport.execute(action); }
            catch (error) {
              this.tickErrors++;
              this.setStatus(`动作执行失败，稍后重试：${(error as Error).message}`);
              break;
            }
          }
          await sleep(settings.behavior.thinkIntervalMs);
        } catch (error) {
          this.tickErrors++;
          this.setStatus(`连接/决策异常：${(error as Error).message}；准备自动恢复`);
          await sleep(reconnectDelay);
          reconnectDelay = Math.min(30000, reconnectDelay * 2);
          try { await this.transport.disconnect(); } catch { /* best effort cleanup */ }
        }
      }
    } finally {
      try { await this.transport.disconnect(); } catch { /* best effort cleanup */ }
      this.cachedPlan = null;
      this.running = false;
      this.activeGoal = '已停止';
      this.setStatus('AI 玩家已停止');
    }
  }

  private scheduleAiPlan(world:Awaited<ReturnType<GameTransport['readWorldSnapshot']>>,settings:AgentSettings) {
    if(!this.planner||!settings.ai.enabled||!settings.ai.planningEnabled||!settings.ai.apiKey) { this.cachedPlan=null; return; }
    if(this.plannerBusy||Date.now()<this.nextPlanAt) return;
    this.nextPlanAt=Date.now()+settings.ai.planningIntervalMs;
    this.plannerBusy=true;
    void this.planner.plan(world,settings).then(decision=>{
      const current=this.getSettings();
      if(decision && this.running && this.transport.isConnected?.() && current.ai.enabled && current.ai.planningEnabled && Boolean(current.ai.apiKey)) {
        this.cachedPlan={decision,expiresAt:Date.now()+Math.max(current.ai.planningIntervalMs,5000)};
        this.setStatus(`AI 规划已就绪：${decision.goal}；${decision.reason}`);
      }
    }).catch(error=>{ this.setStatus(`AI 规划暂不可用，继续使用本地自主逻辑：${(error as Error).message}`); })
      .finally(()=>{this.plannerBusy=false;});
  }

  async stop() {
    this.running = false;
    try { await this.transport.disconnect(); } catch { /* best effort cleanup */ }
    await this.loopPromise?.catch(() => {});
  }
}
