import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';
import type { AgentSettings } from './config.js';
import { validateSettings, saveSettings } from './config.js';
import type { WorldSnapshot } from './types.js';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

type LogEntry={sender:string;message:string;direction:'in'|'out'|'system';timestamp:number};
type FriendWorld={index:number;name:string;host:string;version:string};
export type DashboardState={
  status:string;running:boolean;goal:string;errors:number;connected:boolean;world:WorldSnapshot|null;
  deviceCode:{userCode?:string;verificationUri?:string;message?:string}|null;
  worlds:FriendWorld[];logs:LogEntry[];systemLogs:string[];aiAvailable:boolean;hasApiKey:boolean;botName?:string;
};
export type DashboardHooks={
  getSettings:()=>AgentSettings;
  setSettings:(settings:AgentSettings)=>Promise<void>;
  saveSettings:(settings:AgentSettings)=>Promise<void>;
  connect:()=>Promise<void>;disconnect:()=>Promise<void>;sendChat:(message:string)=>Promise<void>;
  selectWorld:(index:number)=>void;testAi:()=>Promise<string>;getState:()=>DashboardState;
};

export class DashboardServer {
  private server:any;
  private readonly token=randomBytes(24).toString('hex');
  private html='';
  constructor(private hooks:DashboardHooks,private dataDir:string) {}

  async listen(port:number):Promise<void> {
    this.html=await readFile(fileURLToPath(new URL('../public/index.html',import.meta.url)),'utf8');
    this.server=createServer((req:any,res:any)=>void this.route(req,res));
    await new Promise<void>((resolve,reject)=>{
      this.server.once('error',reject);
      this.server.listen(port,'127.0.0.1',()=>{this.server.removeListener('error',reject);resolve();});
    });
  }
  async close():Promise<void> { if(!this.server)return; await new Promise<void>(resolve=>this.server.close(()=>resolve())); this.server=null; }

  private json(res:any,status:number,data:unknown) {
    const body=JSON.stringify(data);
    res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','content-length':Buffer.byteLength(body)});res.end(body);
  }
  private async body(req:any):Promise<any> {
    const parts:Uint8Array[]=[];let size=0;
    for await(const part of req){ size+=part.length; if(size>65536) throw new Error('请求内容过大'); parts.push(part); }
    const raw=Buffer.concat(parts).toString('utf8'); return raw?JSON.parse(raw):{};
  }
  private async route(req:any,res:any):Promise<void> {
    try {
      const url=new URL(req.url??'/',`http://${req.headers.host??'127.0.0.1'}`);
      if(req.method==='GET'&&url.pathname==='/') {
        const body=this.html.replaceAll('__CONTROL_TOKEN__',this.token);
        res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});res.end(body);return;
      }
      if(req.method==='GET'&&url.pathname==='/manifest.webmanifest') {
        const body=JSON.stringify({name:'方块伙伴 AI 2.0',short_name:'方块伙伴',start_url:'/',scope:'/',display:'standalone',background_color:'#0d1420',theme_color:'#111b2b',lang:'zh-CN',icons:[{src:'/icon.svg',sizes:'any',type:'image/svg+xml',purpose:'any maskable'}]});
        res.writeHead(200,{'content-type':'application/manifest+json','cache-control':'no-store'});res.end(body);return;
      }
      if(req.method==='GET'&&url.pathname==='/icon.svg') {
        const body='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><rect width="128" height="128" rx="26" fill="#17334a"/><path d="M20 38 64 14l44 24v52l-44 24-44-24z" fill="#65d8b8"/><path d="m20 38 44 24 44-24M64 62v52" fill="none" stroke="#0c1c2c" stroke-width="7" stroke-linejoin="round"/></svg>';
        res.writeHead(200,{'content-type':'image/svg+xml','cache-control':'public,max-age=86400'});res.end(body);return;
      }
      if(req.method==='GET'&&url.pathname==='/sw.js') {
        const body="const C='blockmate-ai-shell-v1';self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(['/','/manifest.webmanifest','/icon.svg']))));self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method==='GET'&&u.origin===location.origin&&u.pathname==='/'){e.respondWith(fetch(e.request).catch(()=>caches.match('/')));}});";
        res.writeHead(200,{'content-type':'application/javascript','cache-control':'no-cache','service-worker-allowed':'/'});res.end(body);return;
      }
      if(req.method==='GET'&&url.pathname==='/api/state') {
        const state=this.hooks.getState();
        this.json(res,200,state);return;
      }
      if(req.method==='GET'&&url.pathname==='/api/settings') {
        const s=structuredClone(this.hooks.getSettings());
        s.ai.apiKey='';
        this.json(res,200,s);return;
      }
      if(url.pathname.startsWith('/api/')&&req.method==='POST') {
        if(req.headers['x-control-token']!==this.token) { this.json(res,403,{error:'控制令牌无效'});return; }
        const body=await this.body(req);
        switch(url.pathname) {
          case '/api/settings': {
            const previous=this.hooks.getSettings();
            const next=validateSettings(body);
            // A blank key in the UI means keep the existing secret, not erase it.
            if(!next.ai.apiKey) next.ai.apiKey=previous.ai.apiKey;
            await this.hooks.saveSettings(next);
            await this.hooks.setSettings(next);
            this.json(res,200,{ok:true,message:'设置已保存。服务器连接参数变更后请重新连接。'});return;
          }
          case '/api/connect': await this.hooks.connect();this.json(res,200,{ok:true});return;
          case '/api/disconnect': await this.hooks.disconnect();this.json(res,200,{ok:true});return;
          case '/api/chat': {
            const message=String(body.message??'').trim().slice(0,240);
            if(!message) throw new Error('聊天内容不能为空');
            await this.hooks.sendChat(message);this.json(res,200,{ok:true});return;
          }
          case '/api/world/select': this.hooks.selectWorld(Number(body.index));this.json(res,200,{ok:true});return;
          case '/api/ai/test': {const reply=await this.hooks.testAi();this.json(res,200,{ok:true,reply});return;}
          default:this.json(res,404,{error:'接口不存在'});return;
        }
      }
      this.json(res,404,{error:'Not found'});
    } catch(error) { this.json(res,400,{error:(error as Error).message||'请求失败'}); }
  }
}
