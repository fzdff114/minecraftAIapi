import { createRequire } from 'node:module';
import type { AgentSettings } from './config.js';
import type { BotAction, GameTransport, Vec3, WorldSnapshot } from './types.js';
import { WorldState } from './world-state.js';

const require = createRequire(import.meta.url);
const sleep = (ms:number) => new Promise(resolve=>setTimeout(resolve,ms));
type AnyClient = any;
type FriendSession = Record<string, any>;
type DeviceCode = { userCode?:string; verificationUri?:string; message?:string };

export type BedrockTransportHooks = {
  status:(s:string)=>void;
  log:(s:string)=>void;
  deviceCode:(d:DeviceCode|null)=>void;
  worlds:(worlds:Array<{index:number;name:string;host:string;version:string}>)=>void;
  chat:(sender:string,message:string)=>void;
};

/**
 * Real Bedrock client adapter. Xbox authentication is handled by bedrock-protocol's
 * Microsoft device-code flow; passwords are never collected by this app.
 */
export class BedrockTransport implements GameTransport {
  readonly world = new WorldState();
  private client:AnyClient|null=null;
  private connected=false;
  private runtimeId=0n;
  private tick=0n;
  private heldItem:any={network_id:0};
  private hotbarSlot=0;
  private actualGamertag='';
  private pendingWorlds:FriendSession[]=[];
  private resolveWorld?: (s:FriendSession)=>void;
  private rejectWorld?: (e:Error)=>void;
  private connectionTimer?:ReturnType<typeof setTimeout>;
  private yaw=0;
  private pitch=0;
  private isSneaking=false;
  private actionLock=Promise.resolve();
  private heartbeat?:ReturnType<typeof setInterval>;
  private activeMove={x:0,y:0};
  private activeFlags=new Set<string>();
  private velocityY=0;

  constructor(private getSettings:()=>AgentSettings, private authFolder:string, private hooks:BedrockTransportHooks) {}

  isConnected():boolean { return this.connected && Boolean(this.client); }
  getBotName():string { return this.actualGamertag || String(this.client?.profile?.name ?? this.client?.username ?? this.getSettings().server.username); }

  async connect():Promise<void> {
    if(this.isConnected()) return;
    if(this.client) await this.disconnect();
    const settings=this.getSettings();
    const bedrock=require('bedrock-protocol');
    const options:any={
      username:settings.server.username,
      version:settings.server.version,
      offline:false,
      profilesFolder:this.authFolder,
      connectTimeout:30000,
      pingTimeout:10000,
      viewDistance:settings.server.viewDistance,
      raknetBackend:'jsp-raknet',
      useRaknetWorkers:false,
      conLog:(line:any)=>this.hooks.log(String(line).slice(0,500)),
      onMsaCode:(data:any)=>{
        const d:DeviceCode={userCode:String(data.user_code ?? data.userCode ?? ''),verificationUri:String(data.verification_uri ?? data.verificationUri ?? 'https://microsoft.com/link'),message:String(data.message ?? '')};
        this.hooks.deviceCode(d);
        this.hooks.status(`请使用微软账号登录：访问 ${d.verificationUri}，输入代码 ${d.userCode}`);
      }
    };

    if(settings.server.mode==='realm') {
      options.realms={pickRealm:(realms:FriendSession[])=>this.chooseWorld(realms,'Realm')};
    } else if(settings.server.mode==='friendWorld') {
      // Newer bedrock-protocol supports selecting a friend's active Xbox world session.
      options.world={pickSession:(sessions:FriendSession[])=>this.chooseWorld(sessions,'好友世界')};
    } else {
      options.host=settings.server.host;
      options.port=settings.server.port;
      if(settings.server.transport!=='auto') options.transport=settings.server.transport;
      if(settings.server.transport==='nethernet' || settings.server.networkId) {
        options.nethernet={};
        if(settings.server.networkId) options.nethernet.networkId=settings.server.networkId;
      }
      // Current bedrock-protocol can probe RakNet and NetherNet when transport is omitted.
      // An explicit transport narrows discovery; a supplied network ID is kept as a string
      // to preserve the full unsigned 64-bit identifier without JS number precision loss.
    }

    this.hooks.status('正在创建 Bedrock 客户端并启动 Microsoft/Xbox 登录…');
    this.world.setConnected(false);
    const client=bedrock.createClient(options);
    this.client=client;

    client.on('status',(status:any)=>this.hooks.status(`连接状态：${typeof status==='string'?status:JSON.stringify(status).slice(0,220)}`));
    client.on('login',()=>{this.actualGamertag=String(client.profile?.name ?? client.username ?? '');this.hooks.status(`Xbox 身份验证通过（${this.actualGamertag || '已登录'}），正在完成 Bedrock 登录…`);});
    client.on('join',()=>this.hooks.status('已完成服务器登录，正在等待玩家生成…'));
    client.on('spawn',()=>{
      this.connected=true;
      this.actualGamertag=String(client.profile?.name ?? client.username ?? this.actualGamertag);
      this.world.setConnected(true);
      const snap=this.world.snapshot();
      this.runtimeId=BigInt(snap.player.runtimeId||0);
      this.yaw=snap.player.yaw; this.pitch=snap.player.pitch;
      this.hooks.deviceCode(null);
      this.hooks.status('AI 玩家已进入世界，开始本地自主生存');
      this.startHeartbeat();
      this.hooks.log('Bedrock 玩家实体已生成（spawn）');
    });
    client.on('kick',(reason:any)=>{
      this.hooks.status(`服务器拒绝/踢出 AI 玩家：${this.stringifyReason(reason)}`);
      this.connected=false; this.world.setConnected(false);
    });
    client.on('close',()=>{
      this.connected=false; this.world.setConnected(false);
      this.hooks.status('与 Minecraft 服务器的连接已关闭');
    });
    client.on('error',(error:any)=>{
      const message=error instanceof Error?error.message:String(error);
      this.hooks.log(`Bedrock 网络错误：${message}`);
      if(!this.connected) this.hooks.status(`连接错误：${message}`);
    });

    const events=[
      'start_game','move_player','correct_player_move_prediction','set_health','update_attributes',
      'inventory_content','inventory_slot','mob_equipment','mob_armor_equipment','add_entity','add_actor',
      'add_player','add_item_entity','add_item_actor','move_entity','move_entity_delta','move_entity_absolute',
      'set_entity_data','remove_entity','remove_entity_packet','remove_actor','update_block','update_subchunk_blocks','level_chunk','set_time'
    ];
    for(const name of events) client.on(name,(packet:any)=>{
      try {
        this.world.handle(name,packet);
        if(name==='start_game') {
          this.runtimeId=BigInt(this.world.runtimeIdNow||0);
          this.yaw=this.world.yawNow; this.pitch=this.world.pitchNow;
        }
        if(name==='mob_equipment' && String(packet.runtime_entity_id ?? packet.target_runtime_id ?? packet.entity_id)===this.world.runtimeIdNow) {
          this.heldItem=packet.item ?? {network_id:0};
          this.hotbarSlot=Number(packet.selected_slot ?? packet.hotbar_slot ?? packet.slot ?? 0);
        }
      } catch(e) { this.hooks.log(`解析 ${name} 数据包失败：${(e as Error).message}`); }
    });

    client.on('text',(packet:any)=>{
      try {
        const type=packet.type;
        const sender=String(packet.source_name ?? packet.sender ?? '').trim();
        const message=String(packet.message ?? '').trim();
        if(!message) return;
        // 1.26.60 text types: 1=chat, 7=whisper, 8=announcement.
        // Only direct player chat/whispers trigger replies; server announcements must not.
        if(isReplyableChatType(type) && sender) {
          this.world.updateChat(sender,message);
          this.hooks.chat(sender,message);
        }
      } catch(e) { this.hooks.log(`聊天数据包解析失败：${(e as Error).message}`); }
    });

    await new Promise<void>((resolve,reject)=>{
      let settled=false;
      const finish=(err?:Error)=>{
        if(settled) return; settled=true;
        if(this.connectionTimer) clearTimeout(this.connectionTimer);
        this.connectionTimer=undefined;
        if(err) reject(err); else resolve();
      };
      this.connectionTimer=setTimeout(()=>finish(new Error('等待玩家生成超时。检查微软登录、服务器兼容版本及 NetherNet/UDP 连通性。')),180000);
      const onSpawn=()=>finish();
      const onKick=(r:any)=>finish(new Error(`服务器拒绝登录：${this.stringifyReason(r)}`));
      const onClose=()=>{ if(!this.connected) finish(new Error('连接在玩家生成前关闭')); };
      const onError=(e:any)=>{ if(!this.connected) finish(e instanceof Error?e:new Error(String(e))); };
      client.once('spawn',onSpawn); client.once('kick',onKick); client.once('close',onClose); client.once('error',onError);
    }).catch(async error=>{
      await this.disconnect();
      throw error;
    });
  }

  private stringifyReason(reason:any):string {
    if(typeof reason==='string') return reason;
    try { return JSON.stringify(reason); } catch { return String(reason); }
  }

  private async chooseWorld(sessions:FriendSession[],label:'Realm'|'好友世界'):Promise<FriendSession> {
    if(!Array.isArray(sessions)||sessions.length===0) throw new Error(label==='Realm' ? '当前微软账号没有可加入的 Realm。请确认账号已拥有 Realm 或收到邀请。' : '当前没有检测到可加入的 Xbox 好友世界。请确认好友在线、世界允许好友加入，并使用已获授权的 Xbox 账号。');
    this.pendingWorlds=sessions;
    const rows=sessions.map((s,index)=>({index,name:String(s.name ?? s.worldName ?? s.sessionName ?? `${label} ${index+1}`),host:String(s.owner ?? s.ownerName ?? s.hostName ?? s.gamertag ?? ''),version:String(s.version ?? '')}));
    this.hooks.worlds(rows);
    this.hooks.status(`已发现 ${label}，请在控制面板选择`);
    return new Promise((resolve,reject)=>{
      this.resolveWorld=resolve; this.rejectWorld=reject;
      setTimeout(()=>{
        if(this.resolveWorld) { this.resolveWorld=undefined; this.rejectWorld=undefined; reject(new Error('等待选择 Realm 超时')); }
      },120000);
    });
  }

  selectWorld(index:number):void {
    const world=this.pendingWorlds[index];
    if(!world) throw new Error('Realm 选择无效');
    if(!this.resolveWorld) throw new Error('当前没有等待选择的世界');
    const resolve=this.resolveWorld;
    this.resolveWorld=undefined; this.rejectWorld=undefined; this.pendingWorlds=[];
    resolve(world);
  }

  async disconnect():Promise<void> {
    const c=this.client;
    this.client=null; this.connected=false; this.world.setConnected(false);
    this.hooks.worlds([]);
    if(this.heartbeat) clearInterval(this.heartbeat); this.heartbeat=undefined;
    this.activeMove={x:0,y:0}; this.activeFlags.clear(); this.velocityY=0;
    if(this.connectionTimer) clearTimeout(this.connectionTimer);
    this.connectionTimer=undefined;
    if(this.rejectWorld) this.rejectWorld(new Error('连接已取消'));
    this.resolveWorld=undefined; this.rejectWorld=undefined; this.pendingWorlds=[];
    if(c) { try { if(typeof c.disconnect==='function') c.disconnect('方块伙伴 AI 停止'); else c.close(); } catch { try { c.close(); } catch {} } }
  }

  async readWorldSnapshot():Promise<WorldSnapshot> {
    if(!this.isConnected()) throw new Error('AI 玩家尚未进入世界');
    return this.world.snapshot();
  }

  async execute(action:BotAction):Promise<void> {
    if(!this.isConnected()||!this.client) throw new Error('游戏连接未就绪');
    // Serialize packet-level actions so chat, movement and mining do not interleave.
    const run=this.actionLock.then(()=>this.executeUnlocked(action));
    this.actionLock=run.catch(()=>{});
    return run;
  }

  private async executeUnlocked(action:BotAction):Promise<void> {
    switch(action.type) {
      case 'chat': this.sendChat(action.message); return;
      case 'wait': await sleep(Math.max(1,action.ticks)*50); return;
      case 'look': this.yaw=normalYaw(this.yaw+action.yawDelta); this.pitch=clamp(this.pitch+action.pitchDelta,-80,80); this.world.setLook(this.yaw,this.pitch); return;
      case 'lookAt': {
        const me=this.world.positionNow; const dx=action.position.x-me.x; const dz=action.position.z-me.z; const dy=action.position.y-(me.y+1.4);
        this.yaw=normalYaw(Math.atan2(-dx,dz)*180/Math.PI); this.pitch=clamp(-Math.atan2(dy,Math.hypot(dx,dz))*180/Math.PI,-80,80);
        this.world.setLook(this.yaw,this.pitch); return;
      }
      case 'move': await this.move(action.direction,action.ticks); return;
      case 'jump': this.activeFlags.add('jumping'); await sleep(140); this.activeFlags.delete('jumping'); return;
      case 'sneak': if(action.enabled){this.activeFlags.add('sneaking');this.activeFlags.add('persist_sneak');}else{this.activeFlags.delete('sneaking');this.activeFlags.delete('persist_sneak');} return;
      case 'attack': await this.attack(action.targetId); return;
      case 'collect': await this.collect(action.dropId); return;
      case 'break': await this.breakBlock(action.block); return;
      case 'place': await this.placeBlock(action.block,action.face); return;
      case 'useItem': await this.useHeldItem(); return;
    }
  }

  private sendChat(message:string) {
    const safe=String(message).replace(/[\r\n]/g,' ').trim().slice(0,240);
    if(!safe||!this.client) return;
    this.client.queue('text',{type:'chat',needs_translation:false,source_name:String(this.client.profile?.name ?? this.client.username ?? this.getSettings().server.username),xuid:'',platform_chat_id:'',filtered_message:'',message:safe});
  }

  private startHeartbeat():void {
    if(this.heartbeat) clearInterval(this.heartbeat);
    this.heartbeat=setInterval(()=>{
      if(!this.isConnected()||!this.client) return;
      const p=this.world.positionNow;
      const yaw=this.yaw*Math.PI/180;
      // Bedrock yaw 0 faces +Z; positive yaw turns toward -X.
      const forwardX=-Math.sin(yaw),forwardZ=Math.cos(yaw);
      const sideX=Math.cos(yaw),sideZ=-Math.sin(yaw);
      const speed=0.215; // approximate normal walking speed, blocks per 20 Hz simulation tick
      const dx=(forwardX*this.activeMove.y+sideX*this.activeMove.x)*speed;
      const dz=(forwardZ*this.activeMove.y+sideZ*this.activeMove.x)*speed;
      const grounded=this.world.snapshot().player.onGround;
      if(grounded) this.velocityY=0;
      else this.velocityY=Math.max(-3.92,this.velocityY-0.08);
      if(this.activeFlags.has('jumping') && grounded) {
        this.velocityY=0.42;
        this.world.setOnGround(false);
      }
      const dy=this.velocityY;
      const next={x:p.x+dx,y:p.y+dy,z:p.z+dz};
      if(Math.abs(dx)+Math.abs(dy)+Math.abs(dz)>0) this.world.setPosition(next);
      const flagData:any={_value:0n};
      for(const f of this.activeFlags) flagData[f]=true;
      if(this.activeMove.y>0) flagData.up=true;
      if(this.activeMove.y<0) flagData.down=true;
      if(this.activeMove.x<0) flagData.left=true;
      if(this.activeMove.x>0) flagData.right=true;
      const move={x:this.activeMove.x,y:this.activeMove.y};
      const pitchRad=this.pitch*Math.PI/180;
      const camera={x:-Math.sin(yaw)*Math.cos(pitchRad),y:-Math.sin(pitchRad),z:Math.cos(yaw)*Math.cos(pitchRad)};
      try {
        this.client.queue('player_auth_input',{
          pitch:this.pitch,yaw:this.yaw,position:next,move_vector:move,head_yaw:this.yaw,
          input_data:flagData,input_mode:'touch',play_mode:'normal',interaction_model:'crosshair',
          interact_rotation:{x:this.pitch,y:this.yaw},tick:++this.tick,
          delta:{x:dx,y:dy,z:dz},analogue_move_vector:move,
          camera_orientation:camera,raw_move_vector:move
        });
      } catch(e) { this.hooks.log(`移动心跳发送失败：${(e as Error).message}`); }
    },50);
  }

  private setMove(direction:'forward'|'back'|'left'|'right'|null):void {
    if(!direction){this.activeMove={x:0,y:0};return;}
    const vectors={forward:{x:0,y:1},back:{x:0,y:-1},left:{x:-1,y:0},right:{x:1,y:0}};
    this.activeMove=vectors[direction];
  }

  private async move(direction:'forward'|'back'|'left'|'right',ticks:number):Promise<void> {
    const count=Math.max(1,Math.min(100,Math.round(ticks)));
    this.setMove(direction);
    await sleep(count*50);
    this.setMove(null);
  }

  private async attack(targetId:string):Promise<void> {
    let target=this.world.snapshot().nearbyEntities.find(e=>e.id===targetId && e.hostile);
    if(!target) return;
    if(target.distance>3.2) { await this.moveToward(target.position,Math.min(60,Math.ceil((target.distance-2.8)*10))); }
    target=this.world.snapshot().nearbyEntities.find(e=>e.id===targetId && e.hostile);
    if(!target || target.distance>4.5) { this.hooks.log('目标距离仍较远，暂不发送攻击，稍后重新接近'); return; }
    await this.facePosition(target.position);
    const pos=this.world.positionNow;
    this.client!.queue('inventory_transaction',{
      legacy:{legacy_request_id:0},
      transaction_type:'item_use_on_entity',
      actions:[],
      transaction_data:{entity_runtime_id:BigInt(targetId),action_type:'attack',hotbar_slot:this.hotbarSlot,held_item:this.heldItem,hand:0,player_pos:pos,click_pos:{x:0,y:0.8,z:0}}
    });
    await sleep(220);
  }

  private async collect(dropId:string):Promise<void> {
    const drop=this.world.snapshot().nearbyDrops.find(d=>d.id===dropId);
    if(!drop) return;
    if(drop.distance>1.5) await this.moveToward(drop.position,Math.min(60,Math.ceil((drop.distance-0.9)*10)));
    // Bedrock automatically collects item actors on collision; there is no separate pickup command.
    await sleep(400);
  }

  private async moveToward(target:Vec3,ticks:number):Promise<void> {
    await this.facePosition(target);
    await this.move('forward',ticks);
  }

  private async facePosition(target:Vec3):Promise<void> {
    const p=this.world.positionNow; const dx=target.x-p.x,dz=target.z-p.z,dy=target.y-(p.y+1.2);
    this.yaw=normalYaw(Math.atan2(-dx,dz)*180/Math.PI); this.pitch=clamp(-Math.atan2(dy,Math.hypot(dx,dz))*180/Math.PI,-75,75);
    this.world.setLook(this.yaw,this.pitch); await sleep(60);
  }

  private async breakBlock(block:Vec3):Promise<void> {
    const p={x:Math.floor(block.x),y:Math.floor(block.y),z:Math.floor(block.z)};
    // Server-authoritative block breaking is carried by PlayerAuthInput, not standalone player_action.
    this.activeFlags.add('perform_block_actions');
    const sendBlockAction=(type:number)=>{
      const flags:any={_value:0n,perform_block_actions:true};
      this.client!.queue('player_auth_input',{
        pitch:this.pitch,yaw:this.yaw,position:this.world.positionNow,move_vector:{x:0,y:0},head_yaw:this.yaw,
        input_data:flags,input_mode:'touch',play_mode:'normal',interaction_model:'crosshair',
        interact_rotation:{x:this.pitch,y:this.yaw},tick:++this.tick,delta:{x:0,y:0,z:0},
        block_action:[{action:type,position:p,facing:1}]
      });
    };
    sendBlockAction(0); await sleep(250);
    for(let i=0;i<8;i++){sendBlockAction(27);await sleep(100);}
    sendBlockAction(26); await sleep(350);
    sendBlockAction(2); await sleep(80);
    this.activeFlags.delete('perform_block_actions');
  }

  private async placeBlock(block:Vec3,face:'up'|'down'|'north'|'south'|'east'|'west'):Promise<void> {
    if(!this.heldItem || !this.heldItem.network_id) throw new Error('没有同步到手持物品，暂时不能安全放置方块');
    const faceId:{[K in typeof face]:number}={down:0,up:1,north:2,south:3,west:4,east:5};
    const pos=this.world.positionNow;
    this.client!.queue('inventory_transaction',{
      legacy:{legacy_request_id:0},transaction_type:'item_use',actions:[],
      transaction_data:{action_type:'click_block',trigger_type:'player_input',block_position:{x:Math.floor(block.x),y:Math.floor(block.y),z:Math.floor(block.z)},face:faceId[face],hotbar_slot:this.hotbarSlot,hand:0,held_item:this.heldItem,player_pos:pos,click_pos:{x:0.5,y:0.5,z:0.5},block_runtime_id:0,client_prediction:'success',client_cooldown_state:'off'}
    });
    await sleep(250);
  }

  private async useHeldItem():Promise<void> {
    if(!this.heldItem || !this.heldItem.network_id) throw new Error('没有可用的手持物品；需要先切换到食物栏位');
    const pos=this.world.positionNow;
    this.client!.queue('inventory_transaction',{
      legacy:{legacy_request_id:0},transaction_type:'item_use',actions:[],
      transaction_data:{action_type:'click_air',trigger_type:'player_input',block_position:{x:Math.floor(pos.x),y:Math.floor(pos.y),z:Math.floor(pos.z)},face:1,hotbar_slot:this.hotbarSlot,hand:0,held_item:this.heldItem,player_pos:pos,click_pos:{x:0.5,y:0.5,z:0.5},block_runtime_id:0,client_prediction:'success',client_cooldown_state:'off'}
    });
    await sleep(800);
  }
}

function clamp(n:number,min:number,max:number){return Math.min(max,Math.max(min,n));}
function normalYaw(y:number){let n=y%360;if(n>180)n-=360;if(n< -180)n+=360;return n;}

/** Bedrock 1.26.60 AuthorAndMessage values: chat=1, whisper=7, announcement=8. */
export function isReplyableChatType(type:unknown):boolean { return type==='chat' || type==='whisper' || type===1 || type===7; }
