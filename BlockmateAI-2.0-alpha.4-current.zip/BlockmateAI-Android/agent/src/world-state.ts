import type { Drop, Entity, ItemStack, Vec3, WorldSnapshot } from './types.js';

type Packet = Record<string, any>;
const num = (v: any, fallback = 0): number => Number.isFinite(Number(v)) ? Number(v) : fallback;
const text = (v: any, fallback = ''): string => typeof v === 'string' ? v : fallback;
const point = (v: any): Vec3 | undefined => {
  if (!v || typeof v !== 'object') return undefined;
  const x = num(v.x, NaN), y = num(v.y, NaN), z = num(v.z, NaN);
  return Number.isFinite(x) && Number.isFinite(y) && Number.isFinite(z) ? { x, y, z } : undefined;
};
const idString = (v: any): string => v === undefined || v === null ? '' : String(v);
const distance = (a: Vec3, b: Vec3) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
const HOSTILE = /(zombie|skeleton|creeper|spider|enderman|witch|pillager|vindicator|ravager|phantom|drowned|husk|stray|slime|magma_cube|blaze|ghast|hoglin|piglin_brute|warden|guardian|silverfish|vex|evoker|cave_spider|wither_skeleton)/i;

type Tracked = { id:string; type:string; name?:string; position:Vec3; hostile:boolean; health?:number; kind:'entity'|'drop'|'player'; item?:string; count?:number; updatedAt:number };

export class WorldState {
  private tick = 0;
  private position: Vec3 = { x:0, y:64, z:0 };
  private yaw = 0;
  private pitch = 0;
  private runtimeId = '';
  private health = 20;
  private food = 20;
  private armor = 0;
  private dimension = 'overworld';
  private onGround = true;
  private inventory: ItemStack[] = [];
  private selectedItem?: string;
  private entities = new Map<string, Tracked>();
  private recentChat: Array<{sender:string;message:string;timestamp:number}> = [];
  private worldTime = 0;
  private chunkCount = 0;
  private blockUpdates = new Map<string, {name:string;runtimeId?:number;position:Vec3;breakable:boolean}>();
  private connected = false;
  private blockNameForRuntime: (id:number)=>string|undefined = () => undefined;

  setBlockNameResolver(fn:(id:number)=>string|undefined) { this.blockNameForRuntime = fn; }
  setConnected(value:boolean) { this.connected = value; }
  get isConnected() { return this.connected; }
  get positionNow() { return {...this.position}; }
  get yawNow() { return this.yaw; }
  get pitchNow() { return this.pitch; }
  get runtimeIdNow() { return this.runtimeId; }
  setLook(yaw:number,pitch:number) { this.yaw=yaw; this.pitch=pitch; }
  setPosition(position:Vec3) { this.position={...position}; }
  setOnGround(value:boolean) { this.onGround=value; }
  setSelectedItem(name:string|undefined) { this.selectedItem=name; }

  updateChat(sender:string,message:string,timestamp=Date.now()) {
    const s = sender.trim(), m = message.trim();
    if (!m) return;
    this.recentChat.push({sender:s,message:m,timestamp});
    if (this.recentChat.length>30) this.recentChat.shift();
  }

  handle(name:string,packet:Packet) {
    this.tick++;
    switch(name) {
      case 'start_game': {
        this.runtimeId=idString(packet.runtime_entity_id ?? packet.target_runtime_id ?? packet.entity_id);
        this.position=point(packet.player_position ?? packet.position) ?? this.position;
        const r=packet.rotation ?? {}; this.pitch=num(r.x,this.pitch); this.yaw=num(r.y,this.yaw);
        this.dimension=typeof packet.dimension==='number' ? ['overworld','nether','end'][packet.dimension] ?? 'unknown' : text(packet.dimension,this.dimension);
        break;
      }
      case 'move_player':
      case 'correct_player_move_prediction': {
        const id=idString(packet.runtime_entity_id ?? packet.target_runtime_id ?? packet.entity_id);
        if (!id || !this.runtimeId || id===this.runtimeId) {
          this.position=point(packet.position ?? packet.predicted_position) ?? this.position;
          const r=packet.rotation ?? {}; this.pitch=num(r.x,this.pitch); this.yaw=num(r.y,this.yaw);
          this.onGround=Boolean(packet.on_ground ?? this.onGround);
        }
        break;
      }
      case 'set_health': this.health=num(packet.health,this.health); break;
      case 'update_attributes': {
        for(const a of packet.attributes ?? []) {
          const k=text(a.name).toLowerCase();
          if(k.includes('hunger')||k.includes('food')) this.food=num(a.current ?? a.value,this.food);
          if(k.includes('health')) this.health=num(a.current ?? a.value,this.health);
          if(k.includes('armor')) this.armor=num(a.current ?? a.value,this.armor);
        } break;
      }
      case 'inventory_content': {
        const items=packet.input ?? packet.items ?? packet.contents ?? packet.slots;
        if(Array.isArray(items)) this.inventory=items.map((it:any,i:number)=>this.itemStack(it,i)).filter((it:ItemStack)=>it.count>0);
        break;
      }
      case 'inventory_slot': {
        const slot=num(packet.slot,-1); if(slot>=0) { const item=this.itemStack(packet.item ?? packet.item_stack,slot); if(item.count>0) this.inventory=this.inventory.filter(it=>it.slot!==slot).concat(item); else this.inventory=this.inventory.filter(it=>it.slot!==slot); } break;
      }
      case 'mob_equipment':
      case 'mob_armor_equipment': {
        if(idString(packet.runtime_entity_id ?? packet.target_runtime_id ?? packet.entity_id)===this.runtimeId) {
          const selected=num(packet.selected_slot ?? packet.slot,-1);
          if(selected>=0) this.selectedItem=this.inventory.find(it=>it.slot===selected)?.name ?? (this.itemStack(packet.item,selected).name || undefined);
        } break;
      }
      case 'add_entity': case 'add_actor': this.upsertEntity(packet,'entity'); break;
      case 'add_player': this.upsertEntity(packet,'player'); break;
      case 'add_item_entity': case 'add_item_actor': this.upsertEntity(packet,'drop'); break;
      case 'move_entity': case 'move_entity_absolute': {
        const id=idString(packet.runtime_entity_id ?? packet.target_runtime_id ?? packet.entity_id); const e=this.entities.get(id);
        if(e) { e.position=point(packet.position) ?? e.position; e.updatedAt=Date.now(); } break;
      }
      case 'move_entity_delta': {
        const id=idString(packet.runtime_entity_id ?? packet.target_runtime_id ?? packet.entity_id); const e=this.entities.get(id); const delta=point(packet.delta);
        if(e && delta) { e.position={x:e.position.x+delta.x,y:e.position.y+delta.y,z:e.position.z+delta.z}; e.updatedAt=Date.now(); }
        break;
      }
      case 'set_entity_data': {
        const id=idString(packet.runtime_entity_id ?? packet.target_runtime_id ?? packet.entity_id); const e=this.entities.get(id);
        const data=packet.metadata ?? packet.synced_properties ?? [];
        const health=data.find((m:any)=>String(m.key ?? m.name).toLowerCase().includes('health'));
        if(e && health) e.health=num(health.value ?? health.int_value,e.health ?? 0); break;
      }
      case 'remove_entity': case 'remove_entity_packet': case 'remove_actor': {
        this.entities.delete(idString(packet.entity_id ?? packet.runtime_entity_id)); break;
      }
      case 'update_block': {
        const p=point(packet.block_position ?? packet.position);
        if(p) this.recordBlock(p,num(packet.block_runtime_id ?? packet.runtime_id ?? packet.block_id,-1),text(packet.name));
        break;
      }
      case 'update_subchunk_blocks': {
        const base=point(packet.sub_chunk_block_position ?? packet.position);
        const info=packet.blocks_changed ?? {};
        const changed=[...(info.standard ?? info.standards ?? info.blocks_changed_standards ?? []),...(info.extra ?? info.extras ?? info.blocks_changed_extras ?? [])];
        for(const item of changed) {
          const rel=point(item.pos ?? item.position);
          if(!rel) continue;
          const p=base?{x:base.x+rel.x,y:base.y+rel.y,z:base.z+rel.z}:rel;
          this.recordBlock(p,num(item.runtime_id ?? item.runtimeId,-1),text(item.name));
        }
        break;
      }
      case 'level_chunk': this.chunkCount++; break;
      case 'set_time': this.worldTime=num(packet.time,this.worldTime); break;
    }
    // Drop stale actors from old chunk regions so decisions don't chase despawned entities.
    if(this.tick%100===0) {
      const cutoff=Date.now()-45000;
      for(const [id,e] of this.entities) if(e.updatedAt<cutoff && distance(this.position,e.position)>18) this.entities.delete(id);
    }
  }

  private recordBlock(p:Vec3,rid:number,rawName:string) {
    const name=text(rawName,rid>=0 ? this.blockNameForRuntime(rid) ?? `runtime_block_${rid}` : 'unknown_block');
    const key=`${p.x},${p.y},${p.z}`;
    this.blockUpdates.set(key,{name,runtimeId:rid>=0?rid:undefined,position:p,breakable:!/(air|bedrock|barrier|water|lava)/i.test(name)});
    if(this.blockUpdates.size>2400) this.blockUpdates.delete(this.blockUpdates.keys().next().value!);
  }

  private itemStack(raw:any,slot?:number):ItemStack {
    const rawName=text(raw?.name ?? raw?.identifier ?? raw?.item?.name ?? raw?.stack?.name, raw?.network_id ? `runtime_item_${raw.network_id}` : '');
    const name=rawName && !rawName.startsWith('minecraft:') ? `minecraft:${rawName}` : rawName;
    const count=num(raw?.count ?? raw?.stack?.count,0);
    return {name,count,slot};
  }

  private upsertEntity(packet:Packet,kind:Tracked['kind']) {
    const id=idString(packet.runtime_entity_id ?? packet.runtime_id ?? packet.entity_id);
    const p=point(packet.position); if(!id||!p) return;
    const rawType=text(packet.entity_type ?? packet.identifier ?? packet.type,kind);
    const stack=packet.item ?? packet.item_stack ?? packet.item_stack_descriptor ?? {};
    const itemName=text(stack.name ?? stack.identifier ?? stack.item?.name ?? packet.item_name,'unknown_item');
    const old=this.entities.get(id);
    const e:Tracked={id,type:rawType,position:p,hostile:kind==='entity'&&HOSTILE.test(rawType),kind,updatedAt:Date.now()};
    if(kind==='player') e.name=text(packet.username ?? packet.name,'玩家');
    if(kind==='drop') { e.item=itemName.startsWith('minecraft:')?itemName:`minecraft:${itemName}`; e.count=num(stack.count,1); }
    if(old?.health!==undefined) e.health=old.health;
    this.entities.set(id,e);
  }

  snapshot():WorldSnapshot {
    const nearby=[...this.entities.values()].map(e=>({...e,distance:distance(this.position,e.position)})).filter(e=>e.distance<=32);
    const nearbyEntities=nearby.filter(e=>e.kind==='entity').map(e=>({id:e.id,type:e.type,name:e.name,position:e.position,hostile:e.hostile,health:e.health,distance:e.distance} as Entity));
    const nearbyDrops=nearby.filter(e=>e.kind==='drop').map(e=>({id:e.id,item:e.item??'unknown_item',count:e.count??1,position:e.position,distance:e.distance} as Drop));
    const nearbyPlayers=nearby.filter(e=>e.kind==='player').map(e=>({name:e.name??'玩家',position:e.position,distance:e.distance}));
    return {
      tick:this.tick,
      player:{position:{...this.position},yaw:this.yaw,pitch:this.pitch,runtimeId:this.runtimeId,health:this.health,food:this.food,armor:this.armor,selectedItem:this.selectedItem,inventory:this.inventory.map(x=>({...x})),onGround:this.onGround,dimension:this.dimension},
      nearbyEntities,nearbyDrops,nearbyBlocks:[...this.blockUpdates.values()].map(b=>({...b,distance:distance(this.position,b.position)})).filter(b=>b.distance<=8),
      nearbyPlayers,timeOfDay:this.worldTime>12000&&this.worldTime<24000?'night':'day',recentChat:this.recentChat.slice(-12)
    };
  }
}
