import { mkdir, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadSettings, saveSettings, DEFAULT_SETTINGS, type AgentSettings } from './config.js';
import { AiChat } from './ai.js';
import { ChatResponder, type IncomingChat } from './chat-responder.js';
import { BedrockTransport } from './bedrock-transport.js';
import { AgentRuntime } from './runtime.js';
import { AiPlanner } from './planner.js';
import { DashboardServer, type DashboardState } from './dashboard.js';

const root=fileURLToPath(new URL('..',import.meta.url));
const dataDir=join(root,'data');
const authDir=join(dataDir,'microsoft-auth');
const settingsFile=join(dataDir,'settings.json');
await mkdir(authDir,{recursive:true,mode:0o700});
let settings:AgentSettings=await loadSettings(settingsFile);
try { await stat(settingsFile); } catch { await saveSettings(settingsFile,settings); }

let currentStatus='控制面板已启动，等待连接';
let deviceCode:DashboardState['deviceCode']=null;
let friendWorlds:DashboardState['worlds']=[];
const systemLogs:string[]=[];
const chatLogs:DashboardState['logs']=[];
const log=(s:string)=>{const line=`[${new Date().toLocaleTimeString()}] ${s}`;systemLogs.push(line);if(systemLogs.length>250)systemLogs.shift();console.log(line);};
const status=(s:string)=>{currentStatus=s;log(s);};
const ai=new AiChat(settings.ai.baseUrl,settings.ai.apiKey,settings.ai.model,settings.ai.timeoutMs,settings.ai.retries,status);
const transport=new BedrockTransport(()=>settings,authDir,{
  status,
  log,
  deviceCode:d=>{deviceCode=d;},
  worlds:w=>{friendWorlds=w;},
  chat:(sender,message)=>responder?.receive({sender,message,timestamp:Date.now()})
});
const addChat=(entry:DashboardState['logs'][number])=>{chatLogs.push(entry);if(chatLogs.length>180)chatLogs.shift();};
let responder:ChatResponder;
responder=new ChatResponder(()=>settings,ai,message=>transport.execute({type:'chat',message}),entry=>addChat(entry),()=>transport.getBotName(),status,()=>{
  if(!transport.isConnected()) return 'AI 尚未进入世界。';
  const w=transport.world.snapshot();
  const entities=w.nearbyEntities.slice(0,12).map(e=>`${e.name??e.type}${e.hostile?'（敌对）':''}，距离 ${e.distance.toFixed(1)} 格`).join('；')||'附近没有已识别实体';
  const drops=w.nearbyDrops.slice(0,8).map(d=>`${d.item} ×${d.count}，距离 ${d.distance.toFixed(1)} 格`).join('；')||'附近没有已识别掉落物';
  const players=w.nearbyPlayers.slice(0,8).map(p=>`${p.name}，距离 ${p.distance.toFixed(1)} 格`).join('；')||'附近没有其他玩家';
  return `位置 X=${w.player.position.x.toFixed(1)} Y=${w.player.position.y.toFixed(1)} Z=${w.player.position.z.toFixed(1)}；生命 ${w.player.health}/20；饥饿 ${w.player.food}/20；维度 ${w.player.dimension}；附近实体：${entities}；掉落物：${drops}；玩家：${players}；最近服务器聊天：${w.recentChat.slice(-6).map(c=>`${c.sender}: ${c.message}`).join(' | ')}`;
});
const planner=new AiPlanner(ai,status);
const runtime=new AgentRuntime(transport,()=>settings,status,planner);
const dashboard=new DashboardServer({
  getSettings:()=>settings,
  setSettings:async next=>{settings=next;ai.configure(next.ai.baseUrl,next.ai.apiKey,next.ai.model,next.ai.timeoutMs,next.ai.retries);},
  saveSettings:async next=>{await saveSettings(settingsFile,next);},
  connect:async()=>{await runtime.start();},
  disconnect:async()=>{await runtime.stop();},
  sendChat:async message=>{await transport.execute({type:'chat',message});addChat({sender:settings.server.username,message,direction:'out',timestamp:Date.now()});},
  selectWorld:index=>transport.selectWorld(index),
  testAi:async()=>{const answer=await ai.reply('你正在进行连接测试。只回复 OK。',[{role:'user',content:'测试 API 是否正常'}],12);return answer;},
  getState:()=>{
    let world=null; if(transport.isConnected()) { try { world=transport.world.snapshot(); } catch {} }
    const r=runtime.status;
    return {status:currentStatus,running:r.running,goal:r.goal,errors:r.errors,connected:transport.isConnected(),world,deviceCode,worlds:friendWorlds,logs:chatLogs,systemLogs,aiAvailable:settings.ai.enabled&&ai.available,hasApiKey:Boolean(settings.ai.apiKey),botName:transport.getBotName()};
  }
},dataDir);
await dashboard.listen(settings.dashboard.port);
log(`控制面板已启动：http://127.0.0.1:${settings.dashboard.port}`);
log('AI 自主移动与生存决策在本地运行；AI API 不可用时不会暂停移动循环。');
log('Minecraft 连接使用在线 Microsoft/Xbox 认证，登录码会显示在控制面板。');

const shutdown=async()=>{log('正在安全关闭…');await runtime.stop();await dashboard.close();process.exit(0);};
process.on('SIGINT',()=>void shutdown());
process.on('SIGTERM',()=>void shutdown());
