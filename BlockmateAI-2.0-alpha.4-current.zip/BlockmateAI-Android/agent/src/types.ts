export type AgentGoal = 'survive'|'gather_food'|'gather_wood'|'gather_stone'|'fight'|'collect_loot'|'follow_player'|'explore'|'rest';
export type Vec3 = { x: number; y: number; z: number };
export type Entity = { id: string; type: string; name?: string; position: Vec3; health?: number; hostile: boolean; distance: number };
export type ItemStack = { name: string; count: number; slot?: number };
export type Drop = { id: string; item: string; count: number; position: Vec3; distance: number };
export type WorldSnapshot = {
  tick: number;
  player: { position: Vec3; yaw: number; pitch: number; runtimeId: string; health: number; food: number; armor: number; selectedItem?: string; inventory: ItemStack[]; onGround: boolean; dimension: string };
  nearbyEntities: Entity[];
  nearbyDrops: Drop[];
  nearbyBlocks: Array<{ name: string; runtimeId?: number; position: Vec3; distance: number; breakable: boolean }>;
  nearbyPlayers: Array<{ name: string; position: Vec3; distance: number }>;
  timeOfDay: 'day'|'night'|'unknown';
  recentChat: Array<{ sender: string; message: string; timestamp: number }>;
};
export type BotAction =
  | { type:'move'; direction:'forward'|'back'|'left'|'right'; ticks:number }
  | { type:'look'; yawDelta:number; pitchDelta:number }
  | { type:'lookAt'; position:Vec3 }
  | { type:'jump' }
  | { type:'sneak'; enabled:boolean }
  | { type:'attack'; targetId:string }
  | { type:'collect'; dropId:string }
  | { type:'break'; block:Vec3 }
  | { type:'place'; block:Vec3; item:string; face:'up'|'down'|'north'|'south'|'east'|'west' }
  | { type:'useItem'; item:string }
  | { type:'chat'; message:string }
  | { type:'wait'; ticks:number };
export interface GameTransport {
  connect():Promise<void>;
  disconnect():Promise<void>;
  isConnected?():boolean;
  readWorldSnapshot():Promise<WorldSnapshot>;
  execute(action:BotAction):Promise<void>;
}
