import type { AgentGoal, BotAction, WorldSnapshot } from './types.js';
import type { AgentSettings } from './config.js';

export type BrainDecision = { goal: AgentGoal; actions: BotAction[]; reason: string };
/** Local, deterministic survival policy. This is deliberately independent of the AI API. */
export function decide(w: WorldSnapshot, behavior?: AgentSettings['behavior']): BrainDecision {
  const cfg = behavior ?? {
    autonomy: true, attackHostiles: true, collectDrops: true, explore: true, eatWhenHungry: true,
    chatMode: 'all' as const, chatCooldownMs: 8000, thinkIntervalMs: 1000, safeHealth: 8, maxActionTicks: 30
  };
  const maxTicks = cfg.maxActionTicks;
  const threats = w.nearbyEntities.filter(e => e.hostile && e.distance <= 6).sort((a,b)=>a.distance-b.distance);
  const hp = w.player.health;

  if (hp <= Math.max(6, cfg.safeHealth - 2)) return {
    goal: 'survive', reason: '生命值过低，先撤离并寻找安全位置',
    actions: [{ type:'sneak', enabled:true }, { type:'move', direction:'back', ticks:Math.min(maxTicks, 16) }, { type:'wait', ticks:8 }]
  };

  if (threats.length && cfg.attackHostiles) {
    const target = threats[0]!;
    if (hp >= cfg.safeHealth) {
      return { goal:'fight', reason:`发现敌对生物 ${target.name ?? target.type}，主动迎战`, actions:[{type:'lookAt', position:target.position},{type:'attack',targetId:target.id}] };
    }
    return { goal:'survive', reason:'血量偏低，先拉开距离恢复状态', actions:[{type:'move',direction:'back',ticks:Math.min(maxTicks,12)},{type:'look',yawDelta:28,pitchDelta:0}] };
  }

  if (cfg.eatWhenHungry && w.player.food <= 8) {
    const heldFood = w.player.selectedItem && /(?:bread|apple|cooked|beef|porkchop|chicken|carrot|potato|stew|melon)/i.test(w.player.selectedItem);
    if (heldFood) return { goal:'gather_food', reason:`饥饿值较低，使用手持食物 ${w.player.selectedItem}`, actions:[{type:'useItem', item:w.player.selectedItem!}] };
  }

  if (cfg.collectDrops) {
    const loot = w.nearbyDrops.filter(d=>d.distance<6).sort((a,b)=>a.distance-b.distance)[0];
    if (loot) return {goal:'collect_loot',reason:`靠近并收集 ${loot.item}`,actions:[{type:'collect',dropId:loot.id}]};
  }

  if (w.timeOfDay === 'night' && w.player.health < 15) {
    return { goal:'rest', reason:'夜间且生命值不足，降低风险', actions:[{type:'sneak',enabled:true},{type:'wait',ticks:Math.min(maxTicks,20)}] };
  }

  if (cfg.explore) {
    // A deterministic, bounded patrol pattern prevents the bot from standing idle when no API key exists.
    const phase = Math.floor(Date.now() / 7000) % 4;
    const direction = (['forward','right','forward','left'] as const)[phase]!;
    return {goal:'explore',reason:'没有紧急威胁，继续自主探索',actions:[{type:'sneak',enabled:false},{type:'move',direction,ticks:Math.min(maxTicks,10)},{type:'look',yawDelta:phase===1?18:phase===3?-18:5,pitchDelta:0}]};
  }

  return {goal:'rest',reason:'自主探索已关闭，保持安全待机',actions:[{type:'wait',ticks:Math.min(maxTicks,10)}]};
}
