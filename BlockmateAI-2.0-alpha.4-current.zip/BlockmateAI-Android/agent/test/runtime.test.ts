import test from 'node:test';
import assert from 'node:assert/strict';
import { AgentRuntime } from '../src/runtime.js';
import { DEFAULT_SETTINGS } from '../src/config.js';
import type { BotAction, GameTransport, WorldSnapshot } from '../src/types.js';

const snapshot: WorldSnapshot = {
  tick: 1,
  player: { position:{x:0,y:64,z:0}, yaw:0, pitch:0, runtimeId:'1', health:20, food:20, armor:0, inventory:[], onGround:true, dimension:'overworld' },
  nearbyEntities:[], nearbyDrops:[], nearbyBlocks:[], nearbyPlayers:[], timeOfDay:'day', recentChat:[]
};
class FakeTransport implements GameTransport {
  connected = false;
  actions: BotAction[] = [];
  async connect(){ this.connected = true; }
  async disconnect(){ this.connected = false; }
  isConnected(){ return this.connected; }
  async readWorldSnapshot(){ return snapshot; }
  async execute(action: BotAction){ this.actions.push(action); }
}

test('local movement continues when the planner API fails', async () => {
  const settings = structuredClone(DEFAULT_SETTINGS);
  settings.ai.apiKey = 'test-key';
  settings.ai.planningIntervalMs = 4000;
  settings.behavior.thinkIntervalMs = 250;
  const transport = new FakeTransport();
  const failingPlanner = { plan: async () => { throw new Error('simulated API outage'); } };
  const runtime = new AgentRuntime(transport, () => settings, () => {}, failingPlanner as any);
  await runtime.start();
  await new Promise(resolve => setTimeout(resolve, 760));
  await runtime.stop();
  assert.ok(transport.actions.some(action => action.type === 'move'), 'local explore must still issue movement');
});

test('passive API plan is supplemented with local movement', async () => {
  const settings = structuredClone(DEFAULT_SETTINGS);
  settings.ai.apiKey = 'test-key';
  settings.ai.planningIntervalMs = 4000;
  settings.behavior.thinkIntervalMs = 250;
  const transport = new FakeTransport();
  const passivePlanner = { plan: async () => ({ goal:'wait', reason:'passive suggestion', actions:[{type:'wait',ticks:1}] }) };
  const runtime = new AgentRuntime(transport, () => settings, () => {}, passivePlanner as any);
  await runtime.start();
  await new Promise(resolve => setTimeout(resolve, 760));
  await runtime.stop();
  assert.ok(transport.actions.some(action => action.type === 'move'), 'passive API output must not make the bot idle');
});
