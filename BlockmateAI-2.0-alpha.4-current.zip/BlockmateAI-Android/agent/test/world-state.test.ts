import test from 'node:test';
import assert from 'node:assert/strict';
import { WorldState } from '../src/world-state.js';
import { isReplyableChatType } from '../src/bedrock-transport.js';

test('world state tracks player, nearby hostile entities and chat received from Bedrock packets', () => {
  const world = new WorldState();
  world.handle('start_game', { runtime_entity_id: 10n, player_position: { x: 4, y: 65, z: 7 }, rotation: { x: 0, y: 90 }, dimension: 0 });
  world.handle('set_health', { health: 18 });
  world.handle('add_entity', { runtime_entity_id: 22n, entity_type: 'minecraft:zombie', position: { x: 5, y: 65, z: 7 } });
  world.updateChat('PlayerA', '你好，伙伴');
  const snapshot = world.snapshot();
  assert.equal(snapshot.player.runtimeId, '10');
  assert.equal(snapshot.player.health, 18);
  assert.equal(snapshot.nearbyEntities[0]?.hostile, true);
  assert.equal(snapshot.recentChat[0]?.message, '你好，伙伴');
});

test('world state tracks item drops and inventory content', () => {
  const world = new WorldState();
  world.handle('start_game', { runtime_entity_id: 10n, player_position: { x: 0, y: 64, z: 0 } });
  world.handle('inventory_content', { input: [{ name: 'minecraft:bread', count: 3 }] });
  world.handle('add_item_actor', { runtime_entity_id: 33n, position: { x: 1, y: 64, z: 0 }, item: { name: 'minecraft:rotten_flesh', count: 1 } });
  const snapshot = world.snapshot();
  assert.equal(snapshot.player.inventory[0]?.name, 'minecraft:bread');
  assert.equal(snapshot.nearbyDrops[0]?.item, 'minecraft:rotten_flesh');
});

test('only player chat and whispers trigger an AI reply on Bedrock 1.26.60',()=>{ assert.equal(isReplyableChatType(1),true); assert.equal(isReplyableChatType(7),true); assert.equal(isReplyableChatType(8),false); assert.equal(isReplyableChatType('chat'),true); assert.equal(isReplyableChatType('announcement'),false); });
