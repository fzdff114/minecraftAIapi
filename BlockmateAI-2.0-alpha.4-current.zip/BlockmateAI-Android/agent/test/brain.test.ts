import test from 'node:test';
import assert from 'node:assert/strict';
import { decide } from '../src/brain.js';
import type { WorldSnapshot } from '../src/types.js';
const base: WorldSnapshot = { tick:1, player:{position:{x:0,y:64,z:0},yaw:0,pitch:0,runtimeId:'1',health:20,food:20,armor:0,inventory:[],onGround:true,dimension:'overworld'}, nearbyEntities:[],nearbyDrops:[],nearbyBlocks:[],nearbyPlayers:[],timeOfDay:'day',recentChat:[] };
test('backs away when health is critical',()=>{ const d=decide({...base,player:{...base.player,health:5}}); assert.equal(d.goal,'survive'); assert.ok(d.actions.some(a=>a.type==='move'&&a.direction==='back')); });
test('fights nearby hostile mob when adequately equipped',()=>{ const d=decide({...base,player:{...base.player,inventory:[{name:'minecraft:iron_sword',count:1}]},nearbyEntities:[{id:'z1',type:'minecraft:zombie',hostile:true,distance:3,position:{x:2,y:64,z:0}}]}); assert.equal(d.goal,'fight'); assert.ok(d.actions.some(a=>a.type==='attack'));  });
test('collects nearby loot before wandering',()=>{ const d=decide({...base,nearbyDrops:[{id:'d1',item:'minecraft:rotten_flesh',count:1,distance:2,position:{x:1,y:64,z:0}}]}); assert.equal(d.goal,'collect_loot'); });
