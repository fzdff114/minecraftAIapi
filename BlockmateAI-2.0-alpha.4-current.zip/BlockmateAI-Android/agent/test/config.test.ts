import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_SETTINGS, validateSettings } from '../src/config.js';

test('planning settings receive safe defaults when old settings.json is loaded', () => {
  const settings = validateSettings({ server: { mode: 'friendWorld' }, ai: { enabled: true } });
  assert.equal(settings.server.mode, 'friendWorld');
  assert.equal(settings.ai.planningEnabled, true);
  assert.equal(settings.ai.planningIntervalMs, DEFAULT_SETTINGS.ai.planningIntervalMs);
});

test('unsafe non-HTTPS AI endpoints are rejected', () => {
  assert.throws(() => validateSettings({ ai: { baseUrl: 'http://example.invalid/v1' } }), /HTTPS/);
});

test('invalid values are clamped instead of disabling the runtime', () => {
  const settings = validateSettings({ ai: { planningIntervalMs: 1 }, behavior: { thinkIntervalMs: 0, maxActionTicks: 999 } });
  assert.equal(settings.ai.planningIntervalMs, 4000);
  assert.equal(settings.behavior.thinkIntervalMs, 250);
  assert.equal(settings.behavior.maxActionTicks, 100);
});

test('NetherNet network IDs are validated without losing 64-bit precision',()=>{ assert.equal(validateSettings({server:{networkId:'18446744073709551615'}}).server.networkId,'18446744073709551615'); assert.throws(()=>validateSettings({server:{networkId:'18446744073709551616'}}),/64 位/); assert.throws(()=>validateSettings({server:{networkId:'abc'}}),/十进制数字/); });
