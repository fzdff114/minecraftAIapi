import test from 'node:test';
import assert from 'node:assert/strict';
import { ChatResponder } from '../src/chat-responder.js';
import { AiChat } from '../src/ai.js';
import { DEFAULT_SETTINGS } from '../src/config.js';

test('reads incoming player chat and replies locally when API is not configured', async () => {
  const settings = structuredClone(DEFAULT_SETTINGS);
  const sent: string[] = [];
  const logged: string[] = [];
  const responder = new ChatResponder(
    () => settings,
    new AiChat(settings.ai.baseUrl, '', settings.ai.model),
    message => { sent.push(message); },
    entry => { if (entry.direction === 'in') logged.push(entry.message); },
    () => 'BlockmateAI',
    () => {},
    () => '位置 X=1 Y=64 Z=2；附近有僵尸'
  );
  responder.receive({ sender: 'Steve', message: '你好', timestamp: Date.now() });
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.deepEqual(logged, ['你好']);
  assert.equal(sent.length, 1);
  assert.match(sent[0]!, /Steve/);
});

test('does not reply to its own chat echo or when chat mode is off', async () => {
  const settings = structuredClone(DEFAULT_SETTINGS);
  const sent: string[] = [];
  const responder = new ChatResponder(() => settings, new AiChat(settings.ai.baseUrl, '', settings.ai.model), m => { sent.push(m); }, () => {}, () => 'BlockmateAI');
  responder.receive({ sender: 'BlockmateAI', message: 'hello', timestamp: Date.now() });
  settings.behavior.chatMode = 'off';
  responder.receive({ sender: 'Alex', message: 'hello', timestamp: Date.now() });
  await new Promise(resolve => setTimeout(resolve, 20));
  assert.equal(sent.length, 0);
});
