# Third-party notices

## NodeJsBox runtime packaging helpers

The build script downloads `fetch-termux-deps.cjs` and `assemble-runtime.cjs` from:
https://github.com/LinMiZe/NodeJsBox

NodeJsBox is distributed under the MIT License. Its runtime packaging technique is used as a build-time helper only; no NodeJsBox user-facing terminal or container UI is included in this app. The upstream license is available at https://github.com/LinMiZe/NodeJsBox/blob/main/LICENSE.

## Embedded Node runtime and dependencies

The Android APK build downloads the ARM64 Node.js runtime and its required shared libraries from the Termux package repository:
https://packages.termux.dev/apt/termux-main

The Node.js license text is synchronized by the upstream assembly helper. OpenSSL, c-ares, ICU, SQLite, zlib, and libc++ are separate components with their own upstream notices and licenses. Before distributing a production/release APK publicly, verify that the matching copyright and license texts from the downloaded package versions are included in the final distribution.

## Agent dependency

`bedrock-protocol` is an external npm dependency. Its license and dependency notices are included in its npm package metadata and should be retained when redistributing production builds.
