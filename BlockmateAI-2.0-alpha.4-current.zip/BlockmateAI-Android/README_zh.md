# 方块伙伴 AI 2.0 — Android 应用控制版 alpha.4

这是一个独立 Android Studio 工程。应用内有原生启动/停止界面，并把 AI 控制面板嵌入应用自己的 WebView。使用时不需要安装、打开或操作 Termux，也没有终端窗口。

## 应用内包含什么

- 原生 Android 主界面：启动 AI 服务、停止服务、查看后台状态。
- 内置前台服务：将 Bedrock/AI Node 后端作为应用自己的后台服务运行，并显示常驻通知。
- 内嵌控制面板：在应用内部配置微软设备代码登录、服务器地址/端口、Bedrock 版本、AI API 地址/密钥/模型、自治/战斗/采集/探索和聊天设置。
- 聊天与运行日志：继续使用上一版 Agent 控制面板中的聊天、连接状态和日志区域。
- 数据保存在应用私有目录：卸载应用会清除本地设置和 Xbox 登录缓存。

## 运行架构

`Android 原生界面 → Android 前台服务 → 内置 Node 24 ARM64 运行时 → Bedrock Agent → 本机回环控制面板`

Node 进程从 APK 的 `nativeLibraryDir` 启动。运行时从 Termux 官方软件仓库构建包中提取，但只作为 APK 内部依赖；用户设备上不需要安装 Termux。Android app 本身不打开 Shell，也不把控制操作交给外部终端。

## 构建 APK

构建机需要：

- JDK 21
- Android SDK Platform 35 / Build Tools
- Android NDK（供运行时构建脚本可选检测）
- Gradle 8.9
- Node.js 22+ / npm
- `curl`、`bsdtar`（Ubuntu/Debian 可安装 `libarchive-tools`）

在项目根目录运行：

```bash
bash tools/build-android.sh
```

脚本会依次：安装并测试 Agent 依赖、编译 TypeScript、把 Agent 与生产依赖复制进 Android assets、获取 ARM64 Node 24 运行时、组装 `jniLibs/arm64-v8a`，最后构建 APK。

APK 输出路径：

`app/build/outputs/apk/debug/app-debug.apk`

### 不在本机敲命令的构建方式

工程已附带 GitHub Actions：`.github/workflows/android-apk.yml`。把整个工程推送到 GitHub 仓库后，在仓库的 **Actions → Build Blockmate AI Android APK → Run workflow** 启动远程构建。完成后下载 `BlockmateAI-Android-arm64-debug` artifact，里面是 APK。

## 手机上怎么用

1. 安装 APK 并打开「方块伙伴 AI」。
2. 点「启动 AI 服务」。第一次启动会在应用私有目录初始化 Agent。
3. 在应用内控制面板配置服务器地址/端口，或选择好友世界/Realm 流程。
4. 配置微软 Xbox 设备代码登录。应用会打开微软验证网页；只在微软网页输入代码，不要把微软密码或验证码交给 AI API。
5. 填写 AI API 地址、密钥和模型，点“测试 API”，然后保存设置。
6. 点连接后观察 AI 状态、聊天和日志。停止后台服务可点应用顶部的“停止服务”，也可使用常驻通知中的停止操作。

## 重要边界

- 当前 Android 工程只是把 alpha.3 Agent 包装成独立应用，不等于已经证明 Bedrock 1.26.60 在你的设备与目标服务器上成功登录。Xbox 认证、NetherNet/UDP、区块解码、游戏动作必须真机联调。
- 当前 Agent 的聊天读取基于服务器聊天数据包，不是屏幕 OCR；但其真实世界感知和移动/挖掘/放置协议动作仍需要服务器实测，不能把控制面板显示“已运行”理解为角色已经进入世界。
- 这个工程只打包 ARM64（适配 aarch64 Android 手机）。
- Android 可能因省电策略停止长期后台服务。请在系统电池设置中允许本应用后台运行；应用不会尝试绕过系统权限。
- API Key 和 Xbox 登录缓存保存在应用私有目录；不要分享 `files/agent/data` 内容或日志。AI API 请求会把所需聊天上下文和世界摘要发送至你配置的服务商。

## 项目结构

- `app/`：Android 原生 UI、WebView 控制面板容器、后台服务与权限声明。
- `agent/`：Bedrock Agent 源代码与前端。
- `tools/prepare-agent.mjs`：生成 APK 所需的 Agent assets。
- `tools/prepare-runtime.sh`：把 Node 运行时组装进 APK；它会在构建机下载 NodeJsBox 提供的 MIT 许可运行时组装脚本。
- `.github/workflows/android-apk.yml`：远程 APK 构建工作流。

## 版本

`2.0.0-alpha.4` — Android 内嵌控制应用壳；不代表游戏协议联机功能已完成验收。
