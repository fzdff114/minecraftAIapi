# Build status — alpha.4 Android app shell

## Implemented in source
- Native Android main activity with start/stop controls and embedded WebView.
- Foreground service launching the bundled ARM64 Node process from `nativeLibraryDir`.
- App-private persistent agent data directory and log file.
- Microsoft device-code login and AI/server settings remain in the embedded Agent dashboard.
- GitHub Actions workflow and local build scripts for preparing Agent assets and Node runtime.

## Checks performed in this workspace
- `tools/prepare-agent.mjs`: JavaScript syntax check passed.
- `tools/prepare-runtime.sh`: Bash syntax check passed.
- `tools/build-android.sh`: Bash syntax check passed.
- Android manifest, theme, and vector icon XML parse successfully.

## Not verified here
- Android Gradle/Kotlin compilation: not run because this container has no Android SDK/NDK installation.
- APK installation and foreground-service behavior on Android 16: not tested on a device.
- Xbox login and Bedrock 1.26.60 network handshake: not tested.
- In-world AI movement, block interaction, inventory and chat round-trip: not verified by this Android wrapper.

Do not treat this alpha.4 Android shell as a validated production APK or as proof that the underlying Bedrock bot can join a server.
