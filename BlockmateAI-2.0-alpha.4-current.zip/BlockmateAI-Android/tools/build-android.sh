#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

command -v node >/dev/null || { echo "需要 Node.js 20.11+" >&2; exit 2; }
command -v npm >/dev/null || { echo "需要 npm" >&2; exit 2; }
command -v gradle >/dev/null || { echo "需要 Gradle 8.9+ 和 Android SDK 35" >&2; exit 2; }

cd agent
npm install
npm test
npm run build
npm prune --omit=dev
cd "$ROOT"

node tools/prepare-agent.mjs
bash tools/prepare-runtime.sh
gradle --no-daemon :app:assembleDebug

echo "APK: app/build/outputs/apk/debug/app-debug.apk"
