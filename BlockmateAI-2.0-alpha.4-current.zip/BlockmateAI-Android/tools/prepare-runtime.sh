#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

# Node 24 Bionic runtime is bundled inside the APK. These are build-time helpers only;
# users do not install or open Termux. Runtime packaging follows NodeJsBox's MIT-licensed
# Termux-package-to-jniLibs approach.
mkdir -p tools/vendor tools/bin
curl -fsSL https://raw.githubusercontent.com/LinMiZe/NodeJsBox/main/tools/fetch-termux-deps.cjs \
  -o tools/vendor/fetch-termux-deps.cjs
curl -fsSL https://raw.githubusercontent.com/LinMiZe/NodeJsBox/main/tools/assemble-runtime.cjs \
  -o tools/vendor/assemble-runtime.cjs

if ! command -v bsdtar >/dev/null 2>&1; then
  echo "缺少 bsdtar。Ubuntu/Debian 构建机请先安装 libarchive-tools。" >&2
  exit 2
fi
ln -sf "$(command -v bsdtar)" tools/bin/tar
export PATH="$ROOT/tools/bin:$PATH"
node tools/vendor/fetch-termux-deps.cjs --arch aarch64 --with-node
node tools/vendor/assemble-runtime.cjs --arch aarch64

echo "ARM64 Node runtime is ready in app/src/main/jniLibs/arm64-v8a/"
