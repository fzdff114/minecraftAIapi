import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const agent = path.join(root, 'agent');
const out = path.join(root, 'app', 'src', 'main', 'assets', 'agent');

for (const required of [
  path.join(agent, 'dist', 'main.js'),
  path.join(agent, 'public', 'index.html'),
  path.join(agent, 'node_modules', 'bedrock-protocol')
]) {
  try { await fs.access(required); }
  catch { throw new Error(`缺少构建文件：${path.relative(root, required)}。请先在 agent/ 执行 npm install、npm run build。`); }
}

await fs.rm(out, { recursive: true, force: true });
await fs.mkdir(out, { recursive: true });
for (const name of ['dist', 'public', 'node_modules', 'package.json']) {
  await fs.cp(path.join(agent, name), path.join(out, name), { recursive: true, dereference: true, filter: source => !source.split(path.sep).includes('.bin') });
}
console.log(`Agent 资源已复制到 ${path.relative(root, out)}`);
