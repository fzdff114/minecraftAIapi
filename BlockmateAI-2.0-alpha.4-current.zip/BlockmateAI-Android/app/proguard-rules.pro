# Node agent is launched as a bundled native executable; no Java reflection bridge is used.
