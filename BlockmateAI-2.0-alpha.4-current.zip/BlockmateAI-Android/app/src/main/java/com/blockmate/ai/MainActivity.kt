package com.blockmate.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var webView: WebView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private var poller: Runnable? = null

    private val dashboardUrl = "http://127.0.0.1:8765/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        buildAppUi()
        if (AgentService.isBackendAlive) loadDashboard() else showWelcome()
        startStatusPolling()
    }

    private fun buildAppUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(10, 18, 30))
        }
        setContentView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
            setBackgroundColor(Color.rgb(16, 35, 52))
        }
        val title = TextView(this).apply {
            text = "方块伙伴 AI 2.0"
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        status = TextView(this).apply {
            text = "● 后台服务未启动"
            textSize = 13f
            setTextColor(Color.rgb(174, 195, 208))
            setPadding(0, dp(5), 0, 0)
        }
        header.addView(title)
        header.addView(status)
        root.addView(header)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(13, 26, 40))
        }
        startButton = Button(this).apply {
            text = "启动 AI 服务"
            isAllCaps = false
            setOnClickListener { startAgent() }
        }
        stopButton = Button(this).apply {
            text = "停止服务"
            isAllCaps = false
            isEnabled = false
            setOnClickListener { stopAgent() }
        }
        val reload = Button(this).apply {
            text = "刷新"
            isAllCaps = false
            setOnClickListener { loadDashboard() }
        }
        actions.addView(startButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(stopButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(reload, LinearLayout.LayoutParams(0, dp(48), 0.72f))
        root.addView(actions)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(10, 18, 30))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.setSupportZoom(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.host == "127.0.0.1" || uri.host == "localhost") return false
                    return openExternal(uri)
                }
                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    if (url == null) return false
                    val uri = Uri.parse(url)
                    if (uri.host == "127.0.0.1" || uri.host == "localhost") return false
                    return openExternal(uri)
                }
            }
        }
        root.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
    }

    private fun showWelcome() {
        webView.loadDataWithBaseURL(null, """
            <!doctype html><html lang='zh-CN'><meta name='viewport' content='width=device-width, initial-scale=1'>
            <body style='margin:0;background:#0a121e;color:#eaf4f8;font-family:sans-serif;padding:28px'>
            <div style='max-width:620px;margin:10vh auto'>
            <div style='font-size:48px'>🧱</div><h1>欢迎来到方块伙伴 AI</h1>
            <p style='color:#a9bfcd;line-height:1.7'>这是独立 Android 应用。启动内置 AI 服务后，可以在这里配置 Xbox 登录、服务器地址、AI API、聊天和生存行为。</p>
            <div style='background:#13273a;border:1px solid #29445a;border-radius:16px;padding:16px;margin-top:24px'>
            <b>你的 AI 伙伴设定</b><p style='color:#b8cbd6;line-height:1.7;margin-bottom:0'>完全自主生存 · 真人朋友式聊天 · 主动战斗并收集战利品</p></div>
            <p style='color:#7590a1;font-size:13px;margin-top:24px'>点击上方「启动 AI 服务」后进入游戏控制面板。无需打开 Termux。</p>
            </div></body></html>
        """.trimIndent(), "text/html", "UTF-8", null)
    }

    private fun startAgent() {
        val intent = Intent(this, AgentService::class.java).setAction(AgentService.ACTION_START)
        try {
            ContextCompat.startForegroundService(this, intent)
            status.text = "● 正在启动内置 AI 引擎…"
            startButton.isEnabled = false
            toast("正在启动 AI 服务")
            waitForDashboard()
        } catch (e: Exception) {
            startButton.isEnabled = true
            toast("无法启动：${e.message}")
        }
    }

    private fun stopAgent() {
        startService(Intent(this, AgentService::class.java).setAction(AgentService.ACTION_STOP))
        showWelcome()
        status.text = "● 正在停止后台服务…"
        stopButton.isEnabled = false
        startButton.isEnabled = true
    }

    private fun waitForDashboard() {
        thread(name = "blockmate-dashboard-probe") {
            var ready = false
            for (attempt in 0 until 30) {
                try {
                    val conn = (URL(dashboardUrl).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 1000; readTimeout = 1000; requestMethod = "GET"
                    }
                    ready = conn.responseCode == 200
                    conn.disconnect()
                } catch (_: Exception) { }
                if (ready) break
                Thread.sleep(700)
            }
            runOnUiThread {
                if (ready) loadDashboard() else {
                    startButton.isEnabled = true
                    status.text = "● 后台未就绪，请查看应用状态或重新启动"
                    toast("AI 后端未能启动。若提示运行时缺失，需要先完成 APK 构建配置。")
                }
            }
        }
    }

    private fun loadDashboard() {
        webView.loadUrl(dashboardUrl)
    }

    private fun startStatusPolling() {
        poller = object : Runnable {
            override fun run() {
                val alive = AgentService.isBackendAlive
                if (alive) {
                    status.text = "● 内置 AI 服务正在运行 · 控制面板已就绪"
                    status.setTextColor(Color.rgb(95, 220, 180))
                    startButton.isEnabled = false
                    stopButton.isEnabled = true
                } else if (AgentService.isStarting) {
                    status.text = "● 正在初始化内置 AI 引擎…"
                    status.setTextColor(Color.rgb(230, 190, 105))
                    startButton.isEnabled = false
                    stopButton.isEnabled = true
                } else {
                    val error = AgentService.lastError
                    status.text = if (!error.isNullOrBlank()) "● 启动失败：${error.take(70)}" else "● 后台服务未启动"
                    status.setTextColor(if (!error.isNullOrBlank()) Color.rgb(240, 140, 120) else Color.rgb(174, 195, 208))
                    startButton.isEnabled = true
                    stopButton.isEnabled = false
                }
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(poller!!)
    }

    private fun openExternal(uri: Uri): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
            true
        } catch (_: Exception) { false }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 55)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        poller?.let { handler.removeCallbacks(it) }
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }
}
