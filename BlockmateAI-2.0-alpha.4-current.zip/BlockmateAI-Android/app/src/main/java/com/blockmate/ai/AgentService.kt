package com.blockmate.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Runs the bundled Bedrock/AI Node agent inside this app. No Termux app or terminal is used. */
class AgentService : Service() {
    companion object {
        const val ACTION_START = "com.blockmate.ai.action.START"
        const val ACTION_STOP = "com.blockmate.ai.action.STOP"
        const val ACTION_RESTART = "com.blockmate.ai.action.RESTART"
        private const val CHANNEL_ID = "blockmate_agent"
        private const val NOTIFICATION_ID = 2401
        @Volatile var isBackendAlive: Boolean = false
            private set
        @Volatile var isStarting: Boolean = false
            private set
        @Volatile var lastError: String? = null
            private set
    }

    private var process: Process? = null
    private val stopping = AtomicBoolean(false)
    private val started = AtomicBoolean(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // FGS must be promoted immediately after startForegroundService().
        startForeground(NOTIFICATION_ID, notification("正在启动内置 AI 引擎…"))
        when (intent?.action) {
            ACTION_STOP -> stopAgent()
            ACTION_RESTART -> {
                stopping.set(true)
                stopProcess()
                started.set(false)
                stopping.set(false)
                getSharedPreferences("agent", MODE_PRIVATE).edit().putBoolean("wanted", true).apply()
                startAgentOnce()
            }
            else -> {
                getSharedPreferences("agent", MODE_PRIVATE).edit().putBoolean("wanted", true).apply()
                startAgentOnce()
            }
        }
        return START_STICKY
    }

    private fun startAgentOnce() {
        if (!started.compareAndSet(false, true)) return
        stopping.set(false)
        isStarting = true
        lastError = null
        thread(name = "blockmate-agent-launch") {
            try {
                val agentDir = File(filesDir, "agent")
                val prefs = getSharedPreferences("agent", MODE_PRIVATE)
                if (prefs.getString("bundle_version", null) != BuildConfig.VERSION_NAME) {
                    installAssets("agent", agentDir)
                    prefs.edit().putString("bundle_version", BuildConfig.VERSION_NAME).apply()
                }
                if (stopping.get()) return@thread
                val node = File(applicationInfo.nativeLibraryDir, "libnode.so")
                check(node.isFile && node.canExecute()) {
                    "内置 Node 运行时缺失。此源码工程必须先完成 tools/prepare-runtime.sh，再生成 APK。"
                }
                check(File(agentDir, "dist/main.js").isFile) {
                    "AI 后端文件缺失。构建前请运行 agent 的 npm build 和 tools/prepare-agent.mjs。"
                }
                check(File(agentDir, "node_modules/bedrock-protocol").isDirectory) {
                    "Bedrock 协议依赖未打包。请在构建时执行 npm install。"
                }

                val command = listOf(node.absolutePath, "dist/main.js")
                val builder = ProcessBuilder(command)
                    .directory(agentDir)
                    .redirectErrorStream(true)
                builder.environment().apply {
                    put("LD_LIBRARY_PATH", applicationInfo.nativeLibraryDir)
                    put("HOME", filesDir.absolutePath)
                    put("TMPDIR", cacheDir.absolutePath)
                    put("PATH", "/system/bin:/system/xbin")
                    put("NODE_ENV", "production")
                }
                val child = builder.start()
                process = child
                isBackendAlive = true
                updateNotification("AI 控制服务运行中 · 等待连接 Minecraft")
                Log.i("BlockmateAI", "Bundled Node agent started")

                val logFile = File(filesDir, "logs/agent.log").apply { parentFile?.mkdirs() }
                BufferedReader(InputStreamReader(child.inputStream, Charsets.UTF_8)).use { reader ->
                    FileOutputStream(logFile, true).bufferedWriter(Charsets.UTF_8).use { writer ->
                        while (!stopping.get()) {
                            val line = reader.readLine() ?: break
                            val stamped = "[${System.currentTimeMillis()}] $line"
                            Log.i("BlockmateAI-Agent", line)
                            writer.appendLine(stamped)
                            writer.flush()
                        }
                    }
                }
                val exit = child.waitFor()
                Log.w("BlockmateAI", "Agent process exited: $exit")
                updateNotification("AI 后端已退出（代码 $exit）")
                if (!stopping.get()) {
                    getSharedPreferences("agent", MODE_PRIVATE).edit().putBoolean("wanted", false).apply()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            } catch (e: Exception) {
                Log.e("BlockmateAI", "Agent start failed", e)
                lastError = e.message ?: "未知错误"
                updateNotification("启动失败：${e.message?.take(100) ?: "未知错误"}")
                getSharedPreferences("agent", MODE_PRIVATE).edit().putBoolean("wanted", false).apply()
                stopSelf()
            } finally {
                process = null
                isBackendAlive = false
                isStarting = false
                started.set(false)
                if (!stopping.get()) {
                    getSharedPreferences("agent", MODE_PRIVATE).edit().putBoolean("wanted", false).apply()
                }
            }
        }
    }

    private fun installAssets(assetPath: String, target: File) {
        val names = assets.list(assetPath) ?: emptyArray()
        target.mkdirs()
        if (names.isEmpty()) {
            assets.open(assetPath).use { input -> FileOutputStream(target).use { input.copyTo(it) } }
            return
        }
        for (name in names) {
            val childAsset = "$assetPath/$name"
            val childTarget = File(target, name)
            val children = assets.list(childAsset)
            if (children != null && children.isNotEmpty()) {
                installAssets(childAsset, childTarget)
            } else {
                // Refresh packaged runtime files on app update, but preserve the user's data/ directory.
                if (childAsset.contains("/data/")) continue
                assets.open(childAsset).use { input ->
                    childTarget.parentFile?.mkdirs()
                    FileOutputStream(childTarget).use { output -> input.copyTo(output) }
                }
            }
        }
    }

    private fun stopAgent() {
        stopping.set(true)
        getSharedPreferences("agent", MODE_PRIVATE).edit().putBoolean("wanted", false).apply()
        stopProcess()
        isBackendAlive = false
        isStarting = false
        started.set(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun stopProcess() {
        try {
            val current = process
            current?.destroy()
            if (current != null && !current.waitFor(2, TimeUnit.SECONDS)) current.destroyForcibly()
        } catch (e: Exception) { Log.w("BlockmateAI", "Process stop: ${e.message}") }
        process = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, "方块伙伴 AI 后台服务", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "保持 AI 游戏伙伴的服务器连接和自主行动" })
        }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, AgentService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("方块伙伴 AI")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "停止", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }

    override fun onDestroy() {
        stopping.set(true)
        stopProcess()
        isBackendAlive = false
        isStarting = false
        super.onDestroy()
    }
}
